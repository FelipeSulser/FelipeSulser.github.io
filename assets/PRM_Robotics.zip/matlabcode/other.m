[p,in,out] = mapa
