function [ output_args ] = Astar( x_ini, y_ini, x_fin, y_fin, G)
%   Astar.m 
%
%   Very simple and straightforward implementation
%   Simple A star algorithm using cartesian distance
%   as heuristic.

%   
%
%
%   Author: Felipe Sulser


size_g = size(G);
nNodes = size_g(1); % should be a square matrix

ClosedSet = [];
ini = [x_ini;y_ini];
goal = [x_fin;y_fin];
OpenSet = [ini];

came_from = [];
g_cost = NaN(nNodes,nNodes);
g_cost(ini(1),ini(2)) = 0;

f_score = Nan(nNodes,nNodes);
f_score(ini(1),ini(2)) = heuristic(ini,goal);

while ~isEmpty(OpenSet)
    % compute all f_score from now on
    
    
    
end


function h = heuristic(p_ini, p_goal)

h = sqrt((p_goal(1) - p_ini(1))^2 + (p_goal(2) - p_ini(2))^2 );

end

