clear all;
close all;
map = 'H:\Users\PC\matlabcode\dust2.png';
n = 300;
k = 5;
prm(map,n,k)