function Map=CreateMap(NumLandmarks, Size)
Map=Size*2*rand(2,NumLandmarks)-Size;
