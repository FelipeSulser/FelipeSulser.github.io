

function x = intersects(x0,y0,x1,y1,xx1,yy1,xx2,yy2,xx3,yy3,xx4,yy4)






end