%
%Function that returns the readings of a sensor measured from position pose
%It takes a random landmark from map,with "Size" landmarks and its sensor
%noise is var_d
% i is the i-th landmark which we sense 
%
function [rangebear,i] = getObservation(pose,RealMap,Map,Size,var_d,k)
    
   rangebear = zeros(k,2);
   i = zeros(k,1);
   chosen = zeros(k,1);
   for x = 1:k
     randomVal =  round(rand(1)*(Size-1))+1;
    
     
     chosen(x) = randomVal
   end
   dim = size(Map);
   
   if dim(2) <= 0
       k = 0
       
   end

   
   for j =1:k
       
       x = Map(1,chosen(j))
       y = Map(2,chosen(j))
       Map
       RealMap
       %We got the landmark from visible range, but where is it on the real
       %map, which index is it? Need it for simulation purposes
       length(RealMap(:))
       for imRunningOutofNames = 1:(length(RealMap(:))/2)
           if eq(RealMap(1,imRunningOutofNames), x) &&  eq(RealMap(2,imRunningOutofNames), y)
               RealMap(1,imRunningOutofNames)
               imRunningOutofNames
               RealMap(2,imRunningOutofNames)
               i(j) = imRunningOutofNames;
           end
           
       end

       plot(x,y,'*g');

       xx = pose(1);
       yy = pose(2);
       %this is range
       var_d_range = var_d(1,1);
       z = sqrt((x-xx)^2 + (y - yy)^2) +randn*var_d_range;

       %now lets get the bearing
       var_d_bearing = var_d(2,2);
       theta = atan2(y-yy, x-xx) + randn*var_d_bearing;
       angle = theta - pose(3);
       retAngle = angle

        
       rangebear(j,1) = z;
       rangebear(j,2) = retAngle;
       
       %get the index of the real map, from the chosen ladnmark
       
   end
 
   
