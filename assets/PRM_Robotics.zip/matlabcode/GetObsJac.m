function jH = GetObsJac(xPred, land_i, Map)
numLand = length(land_i);
%index to write to final matrix
index = 1;
jH = zeros(length(land_i)*2,3)
for i = 1:numLand
    it = land_i(i);
    x = Map(1,it);
    y = Map(2,it);
    xx = xPred(1);
    yy = xPred(2);
    r = sqrt((x-xx)^2 + (y - yy)^2);
    row1 = [-(x-xx)/r -(y-yy)/r 0];
    row2 = [(y-yy)/(r^2) -(x-xx)/(r^2) -1];
    jH(index,:) = row1;
    index = index+1;
    jH(index,:) = row2;
    index = index+1;
    
end
