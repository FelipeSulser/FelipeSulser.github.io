function EKFLocalization
clear; close all;
 
% Map configuration
Size = 50;
NumLandmarks = 10;
nSensing = 2;
Map=CreateMap(NumLandmarks, Size) % Create map of size [Size*2 Size*2]

mode1 = 'one_landmark';
mode2 = 'one_landmark_in_fov';
mode3 = 'landmarks_in_fov';


mode = mode3
 
% Sensor characterization
SigmaR = 0.2; % Standard deviation of the range 
SigmaB = 0.3; % Standard deviation of the bearing
Q = diag([SigmaR^2 SigmaB^2]); % Cov matrix
fov = pi/2;        % fov = 2*alpha
max_range = 50;  % maximum sensor measurement range

rev_fov = fov/2;
 
% Robot base characterization
SigmaX = 0.2; % Standard deviation in the x axis
SigmaY = 0.3; % Standard deviation in the y axis
SigmaTheta = 0.1; % Bearing standar deviation
R = diag([SigmaX^2 SigmaY^2 SigmaTheta^2]); % Cov matrix
 
% Initialization of poses 
x = [-Size+Size/3 -Size+Size/3 pi/2]';      % Ideal robot pose
xTrue = [-Size+Size/3 -Size+Size/3 pi/2]';  % Real robot pose
xEst = [-Size+Size/3 -Size+Size/3 pi/2]';   % Estimated robot pose by EKF
sEst = zeros(3,3);                          % Uncertainty of estimated robot pose
 
% Drawings
figure(1); hold on; grid off; 
plot(Map(1,:),Map(2,:),'sm','LineWidth',2);hold on;
axis([-Size-5 Size+5 -Size-5 Size+5]);

hold on;
DrawRobot(x,'r');    
DrawRobot(xTrue,'b');
DrawRobot(xEst,'g');
PlotEllipse(xEst,sEst,4);
 
nSteps =20; % Number of motions
turning = 5; % Number of motions before turning (square path)
 
u = [(2*Size-2*Size/3)/turning;0;0]; % Control action

if strcmp(mode,mode1)
    nSensing = 1;
    
    %fov is a circle with max value
    fov = 2*pi
    max_range = intmax
    
end

if strcmp(mode,mode2)
    nSensing = 1;
    fov = pi/2
    max_range = 50
    
end
if strcmp(mode,mode3)
    %two landmarks
    nSensing = 2;
    fov = pi/2
    max_range = 50
    
end
% Let's go!
for k = 1:nSteps-3 % Main loop
   
    u(3) = 0;
    if mod(k,turning) == 0 % Turn?
        u(3) = -pi/2;
    end
    
    x = tcomp(x,u); 			% New pose without noise    
    noise = sqrt(R)*randn(3,1); 	% Generate noise
    noisy_u = tcomp(u,noise); 	% Apply noise to the control action        
    xTrue = tcomp(xTrue,noisy_u);  	% New noisy pose (real robot pose)   
    
    % Get sensor observation/s
    % First get all the landmarks at range from the robot
    % Calculated over x
    
    inRange = 0;
    indexInRange = 1;
    for it = 1:NumLandmarks
         x_land = Map(1,it);
         y_land = Map(2,it);
         
         d = sqrt((xTrue(1)-x_land)^2 + (xTrue(2) - y_land)^2);
         theta = atan2(y_land-xTrue(2), x_land-xTrue(1)) ;
         angle = theta ;
         retAngle =angle;
         
         %calculations for the backwards sensor
         revAngle = AngleWrap(pi + xTrue(3));
       
          
         if d <= max_range          %fov/2 since its half way right, half way left
             lim_min = xTrue(3) - (fov/2);
             lim_max =xTrue(3) + (fov/2);
             
             lim_max2 = revAngle + (rev_fov/2);
             lim_min2 = revAngle - (rev_fov/2);
            
             if retAngle >= lim_min && retAngle <= lim_max
                 
                 %if in range and angle add it to map
                 MapInRange(1,indexInRange) = Map(1,it);
                 MapInRange(2,indexInRange) = Map(2,it);
                 inRange = inRange +1;
                 indexInRange = indexInRange+1;
             else if retAngle>= lim_min2 && retAngle <= lim_max2
                      MapInRange(1,indexInRange) = Map(1,it);
                      MapInRange(2,indexInRange) = Map(2,it);
                      inRange = inRange +1;
                      indexInRange = indexInRange+1;
                 end
                 
             end
             
         end
    end
   
    noneInRange = 0;
    if exist('MapInRange') == 0
        noneInRange = 1;
    end
    
    %if we have at least one landmark at sight
    if noneInRange ~= 1

        [obs,land_i] = getObservation(xTrue,Map,MapInRange,inRange,Q,nSensing);
        %clear for next iteration since we check if the variable has been
        %defined in order to know if any landmarks are in sight
        clear MapInRange
        l = zeros(nSensing,3);
        %polar to cartesian trans for the plotting
       for iter = 1:nSensing
        xx = [obs(iter,1)*cos(obs(iter,2)), obs(iter,1)*sin(obs(iter,2))]';
        reg = tcomp(xTrue,[xx;1]);
        l(iter,1) = reg(1);
        l(iter,2) = reg(2);
        l(iter,3) = reg(3);

       end

        %
        % EKF Localization
        %
       

        % Prediction    
        muPred = tcomp(xEst,u);
        jH = GetObsJac(muPred,land_i,Map) %2k * 3 dimension
        G = RealJ1(xEst,u);
        % R contains sigma ut
        Jac2= RealJ2(xEst,u);
        Rt = Jac2*R*Jac2';
        sigmaPred = G*sEst*G' + Rt;
        % Correction
        range = 1:2:(nSensing*2)
        % we need to scale Q to n observations
        for index_i = range
            Qt(index_i,index_i) = Q(1,1)
            Qt(index_i+1,index_i+1) = Q(2,2)
            
        end
        
     
        Qt
        K = sigmaPred*(jH')*inv(jH*sigmaPred*(jH')  + Qt)
        %hMuPred is as if the observation were taken from mu_pred
       
        hMuPred = zeros(nSensing,2)
        
        muPred
        xTrue
        for index_it = 1:nSensing
            x_land = Map(1,land_i(index_it))
            y_land = Map(2,land_i(index_it))      
            
            angulus = atan2(y_land-muPred(2), x_land-muPred(1));
            angulus = angulus - muPred(3);
          
            z = sqrt((x_land-muPred(1))^2 + (y_land - muPred(2))^2);
            hMuPred(index_it,1) = z
            hMuPred(index_it,2) = angulus
            
            
        end
     
        
        %obs is not a column vector, transform its structure so its
        %r1;a1;r2;a2....
        %same goes for hMuPred
        obsRow = zeros(nSensing*2,1);
        hRow = zeros(nSensing*2,1);
        iterative = 1;
        hMuPred
        obs
        for index_it = 1:nSensing
            obsRow(iterative) = obs(index_it,1);
            hRow(iterative) = hMuPred(index_it,1);
            iterative = iterative+1;
            obsRow(iterative) = obs(index_it,2);
            hRow(iterative) = hMuPred(index_it,2);
            iterative = iterative+1;
           
            
        end
        
        obsRow
        hRow
        xEst = muPred + K*(obsRow - hRow)
       
        sEst = (eye(3) - K*jH)*sigmaPred
        
   
        
        % Drawings
        for it = 1:nSensing
         line([xTrue(1) l(it,1)],[xTrue(2) l(it,2)]);
        end
       
    end %end if observations
    if noneInRange == 1
        muPred = tcomp(xEst,u);
        G = RealJ1(xEst,u);
        % R contains sigma ut
        Jac2= RealJ2(xEst,u);
        Rt = Jac2*R*Jac2';
        sigmaPred = G*sEst*G' + Rt;
        xEst = muPred 
        sEst =sigmaPred
        
    end
    handler = drawFOV(xTrue,fov,max_range,'y');
    handler2 = drawFOV([xTrue(1);xTrue(2);pi+xTrue(3)],rev_fov,max_range,'y');
    DrawRobot(x,'r');
    DrawRobot(xTrue,'b');
    DrawRobot(xEst,'g');
   
    
    
    PlotEllipse(xEst,sEst,4);
    pause
    delete(handler);
    delete(handler2);
    
    
    
end;
 
end % main
 