function [dist_tot,path] = dijkstra(A,s,t,n)
   
    dist = Inf(1,n);
    dist_const = Inf(1,n);
    dist(s) = 0;
    dist_const(s) = 0;

    prev = NaN(1,n);
    optidistance =0;
    dist_tot = 0;
    path = [];
    
    %unvisited nodes
    Q = 1:n;
    while dist_const(t) == Inf
       
        mindist = min(dist);
      
        u = find(dist_const == mindist);
        
        
        if isempty(u) || isempty(Q)
            
            return
        end
        ix = find(Q == u);
      
        Q(ix) = []; %this is how you delete in matlab
        ix2 = find(dist == mindist);
        dist(ix2) = [];
        neighbours = [];
        for it = 1:n
            if it ~= u
                if (A(u,it) ~= 0)
                    neighbours = [neighbours it];
                end
            end
        end
        
         
        
       
        %for each neighbour of u, compute
        for it = 1:length(neighbours)
           alt = dist_const(u) + A(neighbours(it),u) ;
          
         
           
           if alt < dist_const(neighbours(it))
               dist(neighbours(it)) = alt;
               dist_const(neighbours(it)) = alt;
               prev(neighbours(it)) = u;
               
           end
        end
        
        
    end
    
    dist_tot = dist_const(2);
    path = fliplr(reconstruct(prev));
    
    
    
    
    
        
end






%-----------------------------------%


function path = reconstruct(prev)


% goal is pos 2
% backtrack until path found
val = 2;

path = [2];
while val ~= 1
    val = prev(val);
    path = [path,val];
    
    if isnan(val)
        return
    end
end

end