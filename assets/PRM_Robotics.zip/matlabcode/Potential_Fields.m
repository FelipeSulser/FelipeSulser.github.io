function Potential_Fields(x_ini,y_ini,x_fin,y_fin,Map,i,x_axis, y_axis)

    % Algorithm configuration
    
    %constants for the repulsion and attraction
    RadiusOfInfluence = 5; % Objects far away of this radius does not influence
    KGoal= 1;   % Gain for the goal (attractive) field
    KObstacles = 50; % Gain for the obstacles (repulsive) field
    fov = pi*1/3;
   
    side_fov = pi*(2/3);
  
    max_range = 6;
    side_max = 5;
    % Simulation configuration
    k = 0;
    nMaxSteps = 300;
    Theta =0;
    
    
    Theta = atan2(y_axis- y_fin -y_ini,x_fin-x_ini);
    % Drawings
    
    
    
     hold on;
     %axis([0 x_axis 0 y_axis]);
     %set(gcf,'doublebuffer','on');
  %  if ~isempty(Map)
  %       plot(Map(1,:),y_axis - Map(2,:),'r*');hold on;
   %  drawnow;
  %   end
   % disp('Mark the starting point')
    xStart = [x_ini;y_ini];
   % disp('Mark the destination point')
   xGoal = [x_fin;y_fin];
  %  plot(xGoal(1),y_axis -xGoal(2),'gp','MarkerSize',10);

    % Initialization of useful vbles
    xRobot = xStart;
    xDrawn = [xStart(1); y_axis - xStart(1)];
    GoalError =  xGoal - xRobot;
    Hr = DrawRobot([xDrawn;0],'b',[]);


    while(norm(GoalError)>1 && k<nMaxSteps)

        %find distance to all entities
        [SubMap,iFeatures] = getObservationsInsideFOV([xRobot;Theta],Map,fov,max_range);
        [SubMap2,iFeatures2] = getObservationsInsideFOV([xRobot;Theta-(pi/2)],Map,side_fov,side_max);
        [SubMap3,iFeatures3] = getObservationsInsideFOV([xRobot;Theta+(pi/2)],Map,side_fov,side_max);
        
        iFeatTotal = union(iFeatures,iFeatures2);
        iFeatTotal = union(iFeatTotal,iFeatures3);
        
        %parse all
        
        FRep = 0;
        if iFeatTotal == 0
            
           iFeatTotal = []; 
        end
        for it = 1:length(iFeatTotal)
           
            z = Map(:,iFeatTotal(it));
           
            
            distance = sqrt((z(1)-xRobot(1))^2 + (z(2)-xRobot(2))^2);
            
             
             plot(Map(1,iFeatTotal(it)),y_axis - Map(2,iFeatTotal(it)),'g*');hold on;
                   
             a1 = (1/distance) - (1/RadiusOfInfluence);
             a2 = (1/(distance^2));
             delta = (xRobot-Map(:,iFeatTotal(it)));
              FRep = FRep + ((a1*a2)*((delta/distance)));
     
         end
            % multiply times constant
             FRep = KObstacles *FRep;
	%
      
	 %
         
            
   
        
       
          % Point 1.2
          
          Fatt  =  (xRobot - xGoal);
           %normalize
          Fatt = -KGoal*(Fatt/norm(Fatt));
          
         
          
	%

        %
        % Compute total (attractive+repulsive) potential field
        %
            
	%
          % Point 1.3
          FTotal = FRep + Fatt;
	%

        % New vehicle pose
        
        xRobot = xRobot + FTotal;
        xDrawn = [xRobot(1);y_axis - xRobot(2)];
        Theta = atan2(FTotal(2),FTotal(1));
    
        
        % Drawings
        %   -Theta plot because of the damned inverted y axis in matlab's
        %   images
       DrawRobot([xDrawn; -Theta],'k',Hr);
       hFOV = drawFOV([xDrawn;-Theta],fov,max_range,'r');
      hFov2 = drawFOV([xDrawn;-(Theta+pi/2)],side_fov,side_max,'g');
       hFov3 = drawFOV([xDrawn;-(Theta-pi/2)],side_fov,side_max,'g');
        drawnow;

      %  if strcmp(mode,'non_stop')
           % pause(0.1); % for visibility purposes
      %  else
     %       pause;
    %    end
         delete(hFOV);
         delete(hFov2);
        delete(hFov3);

        

        % Update termination conditions
        GoalError =  xGoal - xRobot;
        k = k+1;

    end
    
    
   
    
   
    
    

%-------------------------------------------------------------------------%

function H = DrawRobot(Xr,col,H)

    p=0.005; % percentage of axes size    
    a=axis;
    l1=(a(2)-a(1))*p;
    l2=(a(4)-a(3))*p;
    P=[-1 1 0 -1; -1 -1 3 -1];%basic triangle
    theta = Xr(3)-pi/2;%rotate to point along x axis (theta = 0)
    c=cos(theta);
    s=sin(theta);
    P=[c -s; s c]*P; %rotate by theta
    P(1,:)=P(1,:)*l1+Xr(1); %scale and shift to x
    P(2,:)=P(2,:)*l2+Xr(2);
    if(isempty(H))
        H = plot(P(1,:),P(2,:),col,'LineWidth',0.1);% draw
    else
        set(H,'XData',P(1,:));
        set(H,'YData',P(2,:));
        plot(Xr(1),Xr(2),'b.','MarkerSize',10);
    end
    
    
     
function h = drawFOV(x,fov,max_range,c)
 
    if nargin < 4; c = 'b'; end
    
    alpha = fov/2;
    angles = -alpha:0.01:alpha;
    nAngles = size(angles,2);
    arc_points = zeros(2,nAngles);
    
    for i=1:nAngles
       arc_points(1,i) =  max_range*cos(angles(i));
       arc_points(2,i) =  max_range*sin(angles(i));
 
       aux_point = tcomp(x,[arc_points(1,i);arc_points(2,i);1]);
       arc_points(:,i) = aux_point(1:2);
    end
 
    h = plot([x(1) arc_points(1,:) x(1)],[x(2) arc_points(2,:) x(2)],c);
 
 
%-------------------------------------------------------------------------%
 
 
function [MapInFov,iFeatures] = getObservationsInsideFOV(x,Map,fov,max_range)
   
    nLandmarks = size(Map,2);    
    MapInFov = [];
   
   iFeatures = [];
    z = zeros(2,1);
    
    for i_landmark = 1:nLandmarks
        Delta_x = Map(1,i_landmark) - x(1);
        Delta_y = Map(2,i_landmark) - x(2);
 
        z(1) = norm([Delta_x Delta_y]);        % Range
        z(2) = AngleWrap(atan2(Delta_y,Delta_x) - x(3));  % Bearing
 
        if (z(2) < fov/2) && (z(2) > -fov/2) && (z(1) < max_range)
            MapInFov = [MapInFov Map(:,i_landmark)];
            
            iFeatures = [iFeatures i_landmark];
        end
    end
    