function prm(map,n,k)
 
    

%use k -nearest to reduce connectivity

[X,map] = imread(map);
dx = 0.5; dy = 0.5;
size_x = size(X);

figure(1);hold on;

image_logical = zeros(size_x(1),size_x(2));
for i = 1:size_x(1)
    for j = 1:size_x(2)
        accum = 0;
       for color = 1:3
           if X(i,j,color) == 255
               accum = accum+1;
           end 
       end
       % if all pixels are 255 255 255 -> white, then its free space
        if accum == 3
            image_logical(i,j) = 1;
           
        else
            image_logical(i,j) = 0;
             
        end 
    end
end

RI = imref2d([size_x(2) size_x(1)]);
RI.XWorldLimits = [0 size_x(1)];
RI.YWorldLimits = [0 size_x(2)];
imshow(image_logical',RI);

axis([0 size_x(1) 0  size_x(2)]);hold on

%initial starting point
[xini,yini] =ginput(1);


%check if initial is inside valid region
x_comp = floor(xini);
y_comp = floor(yini);
if image_logical(x_comp+1,y_comp+1) == 0
   msg = 'Initial point not inside value region';
    error(msg)
end

plot(xini,yini,'ro');

%final point
[xfinal,yfinal] = ginput(1);

%check if final point is inside valid region
x_comp = floor(xfinal);
y_comp = floor(yfinal);
if image_logical(x_comp+1,y_comp+1) == 0
   msg = 'Final point not inside value region';
    error(msg)
end


plot(xfinal,yfinal,'b*');

%n+2, we add the initial and the final point
Map = zeros(n+2,2);
Map(1,:) = [xini;yini];
Map(2,:) = [xfinal;yfinal];

%text for initial and final nodes
text(xini+dx,yini+dy, num2str(1));
text(xfinal+dx,yfinal+dy, num2str(2));
counter = 3;
while counter ~= (n+3)
    
    %generate a random sample
    
    x_sample = rand*size_x(1);
    y_sample = rand*size_x(2);
    
    
    x_comp = floor(x_sample);
    y_comp = floor(y_sample);
    
    %since map is composed by discrete numbers, in grid check the cell if
    %its occupied
    
    %means free space
    if image_logical(x_comp+1,y_comp+1) == 1
       
        Map(counter,1) = x_sample;
        Map(counter,2) = y_sample;
        plot(x_sample,y_sample,'sm');
       
        text(x_sample+dx, y_sample+dy, num2str(counter));
        counter = counter+1;
      
    end   
end


%pause;
%now create graph, using bresenhams line algorithm check all cells that are
%in the path of a line

%for each node compute all lines
remove = zeros(n+2,n+2);
matrix = sparse(n+2,n+2);
%for each sample
for i = 1:(n+2)
    x0 = Map(i,1);
    y0 = Map(i,2);
    counter_k = 0;
    
   
   for j = i:(n+2)
       if i~=j
            x1 = Map(j,1);
            y1 = Map(j,2);
                
            [x, y] = bresenham(x0,y0,x1,y1);
             for iter = 1:size(x)
                 if x(iter) == 0
                    x(iter) = 1; %upper bound of grid 
                 end
                 if y(iter) == 0
                    y(iter) = 1;  %upper bound of grid
                 end
                if image_logical(x(iter),y(iter)) == 0
                   remove(i,j) = 1;
                   %matrix(i,j) = 0;
                   %lets not waste cpu usage and break the loop
                   break;
                end
             end
       end 
   end
   
end



ctr = 0;
for i = 1:(n+2)
    inc = incidency(i,matrix,n+2);
    to_add = k -inc;
    if inc < k
        [r_list,distances] = k_nearest(i,to_add,remove,Map,size_x(2));
        for j = 1:length(r_list)
            ctr = ctr+1;
            handler(ctr) =  plot([Map(i,1),Map(r_list(j),1)],[Map(i,2),Map(r_list(j),2)],'g');
            
            matrix(i,r_list(j)) = distances(j);
            matrix(r_list(j),i) = distances(j);
        end
    end
end
 drawnow;
 pause;

[D, P] = dijkstra2(matrix, 1,2);

%dijkstra returns the path in inverse, we want to simulate from start to
%beginning
P = fliplr(P);



if D == Inf
   %means there is no path, non connected nodes
   disp('Non connected nodes');
   return
    
end
%show these points on screen
for node = 1:(length(P)-1)
    n1 = P(node);
    n2 = P(node+1);
    x1 = Map(n1,1);
    y1 = Map(n1,2);
    x2 = Map(n2,1);
    y2 = Map(n2,2);
    
    
    plot([x1,x2],[y1,y2],'b');
end
pause

%delete all the edges that make the image a mess
for i = 1:ctr
   delete(handler(i)) 
end

for node = 1:(length(P)-1)
    n1 = P(node);
    n2 = P(node+1);
    
    x1 = Map(n1,1);
    y1 = size_x(2) -Map(n1,2);
    x2 = Map(n2,1);
    y2 = size_x(2) -Map(n2,2);
    
    %to improve efficiency, in reactive navigation get only a small portion
    %of the map.
    %Better than naive solution
    
    
    min_x = (min(x1,x2))
    %because of the damn image has reversed Y axis, this is how you compute
    %the minimum in our weird axis
    min_y =  size_x(2) - (max(y1,y2))
    max_x = (max(x1,x2))
    max_y =size_x(2) -( min(y1,y2))
  
    liminfx = min_x -10;
    liminfy = min_y -10;
    if min_x <= 10
        liminfx = 1;
    end
    if(min_y <= 10)
        liminfy = 1;
    end
    maxlimx = max_x +10;
    if max_x +10 >= size_x(1)
       maxlimx = size_x(1)-1; 
    end
    maxlimy = max_y + 10;
    if max_y +10 >= size_x(2)
       maxlimy = size_x(2) -1; 
    end
    
    ObstacleMap = [];
    iter = 1;
    
   %liminfx = 1;
   %liminfy = 1;
   %maxlimx = size_x(1);
   %maxlimy = size_x(2);
   
   liminfx = floor(liminfx);
   liminfy = floor(liminfy);
   maxlimx = ceil(maxlimx);
   maxlimy = ceil(maxlimy);
   
    for i = liminfx:1:maxlimx
        for j = liminfy:1:maxlimy
            if image_logical(i,j) == 0
               ObstacleMap(1,iter) = i;
               ObstacleMap(2,iter) = size_x(2) - j;
               iter = iter+1;
            end
        end
    end
    Potential_Fields(x1,y1,x2,y2,ObstacleMap,node,size_x(1),size_x(2));
end

end
%----------------------------------------------------------------%

function val = incidency(i,matrix,len)
	val = 0;
    for it = 1:len
        if i ~= it
            %zero is by defaiult the initial value, so no path with 0
            if (matrix(i,it) ~= 0) 
           %if ~isnan(matrix(i,it))
                val = val+1;
            end
        end
    end


end
%----------------------------------------------------------------%

function [result_list,distances] = k_nearest(i,k, remove, Map,y_scale)
    reg = size(Map);
    size_map = reg(1);
    
    point =[Map(i,1);Map(i,2)];
   
    list = [];
    assoc = [];
    pos = 1;
    
    for iter = i:size_map
        if i~=iter
            if remove(i,iter) ~= 1
                p2 = [Map(iter,1);Map(iter,2)];
                dist = distance(point,p2,y_scale);
                list(pos) = dist;
                assoc(pos) = iter; %we need to track its position in the matrix
                pos = pos+1;
            end
        end
    end
    
    
    %now do a sortrow
    order = [list;assoc]';
 
   % output
   result = [];
   
   if ~isempty(order)
       result = sortrows(order,1);
       l = result(:,1);
       ass = result(:,2);
   else
       l = [];
       ass = [];
   end
   result_list = [];
   counter = 1;
   distances = [];
   for it = 1:size(l)
       if counter <= k
            result_list(counter) =  ass(it);
            distances(counter) = l(it);
            counter = counter+1;
       end
     
       
   end
   
   
   
  
end




%-------------------------------------------------------------------%

function d = distance(p1,p2,y_scale)
    y1 = y_scale - p1(2);
    y2 = y_scale -p2(2);
    d = sqrt((p1(1)-p2(1))^2 + (y1-y2)^2);
end

